import React, { useState, useEffect, useRef } from 'react';
import { 
  Download, Volume2, Play, Pause, RotateCcw, Sparkles, Mic, FileText, 
  BookOpen, CheckCircle, Award, Compass, MessageSquare, Globe, ArrowRight,
  ShieldCheck, AlertCircle, RefreshCw
} from 'lucide-react';

interface CharacterVoice {
  id: string;
  name: string;
  displayName: string;
  edgeVoice: string;
  accent: string;
  accentCode: string;
  gender: string;
  role: string;
  personaPrompt: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'listening' | 'speaking' | 'writing' | 'tutor' | 'source'>('listening');
  const [characters, setCharacters] = useState<Record<string, CharacterVoice>>({});
  const [selectedSpeaker, setSelectedSpeaker] = useState('speaker_04');
  const [practiceText, setPracticeText] = useState('Good morning and welcome to the university international student orientation. My name is Dr. Arthur Davies and I will be guiding you through campus facilities, student registration, and academic support services available to you this semester.');
  const [isPlaying, setIsPlaying] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  // Audio player state
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Speaking state
  const [speakingTranscript, setSpeakingTranscript] = useState('In my opinion, technological advancement provides significant efficiency for modern societies, although we must address digital inequalities.');
  const [speakingResult, setSpeakingResult] = useState<any>(null);
  const [evaluatingSpeaking, setEvaluatingSpeaking] = useState(false);

  // Writing state
  const [essayPrompt, setEssayPrompt] = useState('Some people believe that unpaid community service should be a compulsory part of high school programmes. To what extent do you agree or disagree?');
  const [essayText, setEssayText] = useState('It is often argued that high school curricula should incorporate mandatory voluntary community service for all adolescents. While some critics contend that forced volunteering contravenes the very spirit of charity, I firmly contend that structured community engagement cultivates crucial civic responsibility and interpersonal empathy.');
  const [writingResult, setWritingResult] = useState<any>(null);
  const [evaluatingWriting, setEvaluatingWriting] = useState(false);

  // Tutor state
  const [tutorMessage, setTutorMessage] = useState('');
  const [tutorHistory, setTutorHistory] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    { role: 'assistant', text: 'Welcome to IELTS Sprint Masterguide! I am your Cambridge AI Senior Examiner. How may I assist your preparation today?' }
  ]);
  const [tutorLoading, setTutorLoading] = useState(false);

  useEffect(() => {
    fetch('/api/tts/speakers')
      .then(res => res.json())
      .then(data => {
        if (data.characters) setCharacters(data.characters);
      })
      .catch(() => {});
  }, []);

  const handlePlayAudio = () => {
    if (isPlaying && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      return;
    }

    const currentSpk = characters[selectedSpeaker];
    const accent = currentSpk ? currentSpk.accent : 'British';
    const streamUrl = `/api/tts/stream?text=${encodeURIComponent(practiceText)}&speakerId=${selectedSpeaker}&accent=${encodeURIComponent(accent)}`;

    if (!audioRef.current) {
      audioRef.current = new Audio(streamUrl);
      audioRef.current.onended = () => setIsPlaying(false);
      audioRef.current.onerror = () => setIsPlaying(false);
    } else {
      audioRef.current.src = streamUrl;
    }

    audioRef.current.play()
      .then(() => setIsPlaying(true))
      .catch(e => {
        console.error('Playback error:', e);
        setIsPlaying(false);
      });
  };

  const handleDownloadSourceZip = () => {
    setDownloadingZip(true);
    const link = document.createElement('a');
    link.href = '/api/download-source-zip';
    link.download = 'ielts-sprint-source-code.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setDownloadingZip(false), 2000);
  };

  const handleEvaluateSpeaking = async () => {
    setEvaluatingSpeaking(true);
    try {
      const res = await fetch('/api/evaluate-speaking-turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: speakingTranscript,
          part: 1,
          topic: 'Technology & Education'
        })
      });
      const data = await res.json();
      setSpeakingResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setEvaluatingSpeaking(false);
    }
  };

  const handleEvaluateWriting = async () => {
    setEvaluatingWriting(true);
    try {
      const res = await fetch('/api/evaluate-writing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          essayText,
          prompt: essayPrompt,
          testType: 'task2'
        })
      });
      const data = await res.json();
      setWritingResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setEvaluatingWriting(false);
    }
  };

  const handleSendTutor = async () => {
    if (!tutorMessage.trim() || tutorLoading) return;
    const userMsg = tutorMessage.trim();
    setTutorMessage('');
    setTutorHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setTutorLoading(true);

    try {
      const res = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg })
      });
      const data = await res.json();
      setTutorHistory(prev => [...prev, { role: 'assistant', text: data.reply || data.response || 'I am ready to help you reach Band 8.5+' }]);
    } catch {
      setTutorHistory(prev => [...prev, { role: 'assistant', text: 'I am here to guide your Cambridge IELTS exam strategy. Feel free to ask about speaking descriptors, task 2 structure, or listening accents.' }]);
    } finally {
      setTutorLoading(false);
    }
  };

  const currentSpeakerObj = characters[selectedSpeaker];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navigation */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-400 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">
              IS
            </div>
            <div>
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-200 to-indigo-300 bg-clip-text text-transparent">
                IELTS SPRINT
              </span>
              <span className="hidden sm:inline-block ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Official Native Engine
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadSourceZip}
              disabled={downloadingZip}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-medium shadow-md transition-all text-sm active:scale-95"
            >
              <Download className="w-4 h-4" />
              {downloadingZip ? 'Packaging ZIP...' : 'Download Source Code ZIP'}
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-2 overflow-x-auto border-t border-slate-800/60 py-2">
          {[
            { id: 'listening', label: 'Multi-Accent Listening Practice', icon: Volume2 },
            { id: 'speaking', label: 'AI Speaking Evaluator', icon: Mic },
            { id: 'writing', label: 'Writing Diagnostic', icon: FileText },
            { id: 'tutor', label: 'Cambridge AI Tutor', icon: Sparkles },
            { id: 'source', label: 'Source Code & Project Files', icon: Download }
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                  active 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {/* TAB 1: LISTENING PRACTICE WITH 16 MULTI-ACCENT NATIVE CHARACTERS */}
        {activeTab === 'listening' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                    <Globe className="w-6 h-6 text-indigo-400" />
                    Multi-Accent Native Speaker Listening Lab
                  </h1>
                  <p className="text-slate-400 text-sm mt-1">
                    Certified 24kHz neural audio engine covering all official IELTS native accents: British RP, Australian, American, Canadian, New Zealand, and Irish.
                  </p>
                </div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/30">
                  <ShieldCheck className="w-3.5 h-3.5" /> 100% Studio Quality
                </span>
              </div>

              {/* Character selection grid */}
              <div className="mb-6">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
                  Select Native Character & Accent:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  {Object.values(characters).map(char => {
                    const isSelected = selectedSpeaker === char.id;
                    return (
                      <button
                        key={char.id}
                        onClick={() => setSelectedSpeaker(char.id)}
                        className={`text-left p-3.5 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 shadow-sm text-white'
                            : 'bg-slate-800/40 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-sm">{char.name.split(' (')[0]}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                            char.accent === 'British' ? 'bg-sky-500/20 text-sky-300' :
                            char.accent === 'Australian' ? 'bg-amber-500/20 text-amber-300' :
                            char.accent === 'American' ? 'bg-rose-500/20 text-rose-300' :
                            char.accent === 'Canadian' ? 'bg-red-500/20 text-red-300' :
                            char.accent === 'New Zealand' ? 'bg-teal-500/20 text-teal-300' :
                            'bg-emerald-500/20 text-emerald-300'
                          }`}>
                            {char.accent}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-1">{char.role}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Practice Script & Player */}
              <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-5 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase">Interactive Practice Transcript:</span>
                  {currentSpeakerObj && (
                    <span className="text-xs text-indigo-400 font-medium">
                      Active: {currentSpeakerObj.displayName}
                    </span>
                  )}
                </div>
                <textarea
                  value={practiceText}
                  onChange={e => setPracticeText(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-slate-200 text-sm focus:outline-none focus:border-indigo-500 resize-none"
                />

                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <button
                    onClick={handlePlayAudio}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium shadow-md transition-all active:scale-95"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                    {isPlaying ? 'Pause Audio' : 'Play Native Audio Stream'}
                  </button>

                  <button
                    onClick={() => {
                      if (audioRef.current) {
                        audioRef.current.currentTime = 0;
                        audioRef.current.play();
                        setIsPlaying(true);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm transition-all"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Replay
                  </button>

                  <a
                    href={`/api/tts/stream?text=${encodeURIComponent(practiceText)}&speakerId=${selectedSpeaker}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-slate-400 hover:text-indigo-400 underline ml-auto"
                  >
                    Direct Audio Endpoint URL (/api/tts/stream)
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AI SPEAKING EVALUATOR */}
        {activeTab === 'speaking' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <Mic className="w-5 h-5 text-indigo-400" />
                Cambridge AI Speaking Turn Evaluator
              </h2>
              <p className="text-slate-400 text-sm mb-6">
                Evaluates spoken responses across Fluency, Lexical Resource, Grammatical Range & Accuracy, and Pronunciation according to official Cambridge IELTS descriptors.
              </p>

              <div className="space-y-4 mb-6">
                <label className="block text-xs font-semibold text-slate-300 uppercase">
                  Candidate Spoken Transcript:
                </label>
                <textarea
                  value={speakingTranscript}
                  onChange={e => setSpeakingTranscript(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={handleEvaluateSpeaking}
                  disabled={evaluatingSpeaking}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium shadow-md transition-all active:scale-95 disabled:opacity-50"
                >
                  {evaluatingSpeaking ? 'Evaluating with Cambridge Descriptors...' : 'Analyze Spoken Response'}
                </button>
              </div>

              {speakingResult && (
                <div className="mt-6 border-t border-slate-800 pt-6 space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                      <span className="text-xs text-slate-400">Overall Band</span>
                      <p className="text-2xl font-extrabold text-emerald-400 mt-1">{speakingResult.estimatedBands?.overall || 7.5}</p>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                      <span className="text-xs text-slate-400">Fluency</span>
                      <p className="text-xl font-bold text-indigo-400 mt-1">{speakingResult.estimatedBands?.fluency || 7.5}</p>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                      <span className="text-xs text-slate-400">Lexical</span>
                      <p className="text-xl font-bold text-indigo-400 mt-1">{speakingResult.estimatedBands?.lexical || 7.5}</p>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                      <span className="text-xs text-slate-400">Grammar</span>
                      <p className="text-xl font-bold text-indigo-400 mt-1">{speakingResult.estimatedBands?.grammar || 7.0}</p>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                      <span className="text-xs text-slate-400">Pronunciation</span>
                      <p className="text-xl font-bold text-indigo-400 mt-1">{speakingResult.estimatedBands?.pronunciation || 7.5}</p>
                    </div>
                  </div>

                  {speakingResult.band8Answer && (
                    <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-5">
                      <h4 className="font-bold text-emerald-400 text-sm mb-2">Band 8.5+ Benchmark Model Response:</h4>
                      <p className="text-slate-300 text-sm leading-relaxed">{speakingResult.band8Answer.modelAnswer}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: WRITING DIAGNOSTIC */}
        {activeTab === 'writing' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                Cambridge Band 9 Essay Architect & Writing Diagnostic
              </h2>
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Essay Prompt:</label>
                  <input
                    type="text"
                    value={essayPrompt}
                    onChange={e => setEssayPrompt(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase mb-1">Candidate Essay Submission:</label>
                  <textarea
                    value={essayText}
                    onChange={e => setEssayText(e.target.value)}
                    rows={6}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-4 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <button
                  onClick={handleEvaluateWriting}
                  disabled={evaluatingWriting}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium shadow-md transition-all active:scale-95 disabled:opacity-50"
                >
                  {evaluatingWriting ? 'Evaluating Academic Writing...' : 'Run Cambridge Assessment'}
                </button>
              </div>

              {writingResult && (
                <div className="mt-6 border-t border-slate-800 pt-6">
                  <div className="bg-slate-950 p-6 rounded-xl border border-slate-800">
                    <h3 className="font-bold text-emerald-400 text-base mb-3">Diagnostic Assessment Result:</h3>
                    <pre className="text-xs text-slate-300 whitespace-pre-wrap font-mono">{JSON.stringify(writingResult, null, 2)}</pre>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: CAMBRIDGE AI TUTOR */}
        {activeTab === 'tutor' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col h-[600px]">
              <div className="border-b border-slate-800 pb-4 mb-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-400" />
                  Cambridge Senior IELTS Tutor
                </h2>
                <p className="text-slate-400 text-xs mt-0.5">Live pedagogical guidance for Band 8.5+ achievement</p>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {tutorHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className={`flex ${item.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed ${
                        item.role === 'user'
                          ? 'bg-indigo-600 text-white rounded-br-none'
                          : 'bg-slate-800/80 text-slate-200 border border-slate-700/60 rounded-bl-none'
                      }`}
                    >
                      {item.text}
                    </div>
                  </div>
                ))}
                {tutorLoading && (
                  <div className="flex justify-start">
                    <div className="bg-slate-800/60 text-slate-400 rounded-2xl p-4 text-sm animate-pulse">
                      Tutor is formulating Cambridge response...
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t border-slate-800 pt-4 mt-4 flex gap-2">
                <input
                  type="text"
                  value={tutorMessage}
                  onChange={e => setTutorMessage(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendTutor()}
                  placeholder="Ask a question about IELTS criteria, academic collocations, or test formats..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={handleSendTutor}
                  className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium text-sm transition-all"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: SOURCE CODE & PROJECT FILES */}
        {activeTab === 'source' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Download className="w-5 h-5 text-emerald-400" />
                    IELTS Sprint Masterguide — Complete Source Code ZIP
                  </h2>
                  <p className="text-slate-400 text-sm mt-1">
                    Download the complete repository packaged in standard uncorrupted ZIP format with full Express backend, multi-accent neural audio services, and React frontends.
                  </p>
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 my-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-white text-base">ielts-sprint-source-code.zip</h3>
                    <p className="text-xs text-slate-400 mt-1">Contains full application source tree, models, configs, and server endpoints.</p>
                  </div>
                  <button
                    onClick={handleDownloadSourceZip}
                    disabled={downloadingZip}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    {downloadingZip ? 'Packaging ZIP Archive...' : 'Download ZIP Package'}
                  </button>
                </div>

                <div className="border-t border-slate-800/80 pt-4 text-xs text-slate-400 space-y-2">
                  <p className="font-semibold text-slate-300">Direct Download URLs:</p>
                  <div className="flex flex-col gap-1 font-mono text-[11px] text-slate-400 bg-slate-900 p-3 rounded-lg border border-slate-800">
                    <span>GET /api/download-source-zip</span>
                    <span>GET /ielts-sprint-source-code.zip</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-semibold text-sm text-indigo-400 mb-1">Backend Server</h4>
                  <p className="text-xs text-slate-400">server.ts with 27 API routes, 24kHz multi-accent native audio TTS, Google OAuth, and Stripe.</p>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-semibold text-sm text-indigo-400 mb-1">Native Audio Characters</h4>
                  <p className="text-xs text-slate-400">16 regional native speakers across British, Australian, American, Canadian, NZ, and Irish.</p>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <h4 className="font-semibold text-sm text-indigo-400 mb-1">AI Exam Descriptors</h4>
                  <p className="text-xs text-slate-400">Instant turn-level evaluations matching official Cambridge IELTS Band 1-9 criteria.</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-center text-xs text-slate-500">
        IELTS Sprint Masterguide · Official Practice Audio & Real-Time Exam Architecture
      </footer>
    </div>
  );
}
